import openai
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = "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"


class API:
    def __init__(self, prompt):
        self.prompt = prompt

    def get_result(self):
        completion = openai.Completion.create(model="text-davinci-002", prompt=self.prompt, max_tokens=2048, stop=None,
                                              temperature=0.2)
        # print(completion)
        print(self.prompt)
        text = completion.choices[0].text
        return text
