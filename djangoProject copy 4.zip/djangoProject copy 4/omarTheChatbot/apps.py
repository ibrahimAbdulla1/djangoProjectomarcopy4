from django.apps import AppConfig


class OmarTheChatbotConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'omarTheChatbot'
