from django.shortcuts import render
from .api_Request import API


# Function to redirect the user to the chat page
def omarTheChatbot(request):
    request.session["chat_history"] = []
    context = {"state": "0", "chat_history": request.session.get("chat_history")}
    return render(request, 'omarTheChatbot.html', context=context)


# Function for chatting with the bot
def omarTheChatbot_view(request, state, temp_arr=None):
    # user input from template form
    user_input = request.POST.get("user_input")
    if state == "0":
        request.session['user_name'] = user_input
        temp_arr = request.session.get("chat_history")
        print(temp_arr)
        temp_arr.append(("Bot",
                         "Hi, I am omarTheChatbot, the artificial intelligence chatbot May I ask for you for your name?"))
        temp_arr.append(("You", user_input))
        request.session["chat_history"] = temp_arr
        context = {"state": "1", "chat_history": request.session.get("chat_history")}
        return render(request, 'omarTheChatbot.html', context=context)
    # while state = 1, means asking for age
    elif state == "1":
        request.session['age'] = user_input
        temp_arr = request.session.get("chat_history")
        temp_arr.append(("Bot", "May I ask for your age"))
        temp_arr.append(("You", user_input))
        request.session["chat_history"] = temp_arr
        context = {"state": "2", "chat_history": request.session.get("chat_history")}
        return render(request, 'omarTheChatbot.html', context=context)

    # while state = 2, means asking for sex of the user
    elif state == "2":
        request.session['sex'] = user_input
        temp_arr = request.session.get("chat_history")
        temp_arr.append(("Bot", "What was the sex assigned to you at birth?"))
        temp_arr.append(("You", user_input))
        request.session["chat_history"] = temp_arr
        context = {"state": "3", "chat_history": request.session.get("chat_history")}
        return render(request, 'omarTheChatbot.html', context=context)

    # while state = 3, means asking for the symptoms the user is facing
    elif state == "3":
        request.session['symptoms'] = user_input
        temp_arr = request.session.get("chat_history")
        temp_arr.append(("Bot", "May I ask you your symptoms so that Identify your injury?"))
        temp_arr.append(("You", user_input))

        # Prompt making
        prompt = f"My name is {request.session.get('user_name')}, my age is {request.session.get('age')}. And I am a {request.session.get('sex')}. My symptoms are:\n{request.session.get('symptoms')}.\nNow tell me what type of Injury or disease can it be? Generate the response with the text at first = \"Hi {request.session.get('user_name')}!\""

        # Getting the OpenAI API result
        obj = API(prompt)
        result = obj.get_result()
        temp_arr.append(("Bot", result))
        # Clear chat_history after generating the response
        request.session["chat_history"] = []
        context = {"state": "4", "chat_history": temp_arr, "response_data": result}
        return render(request, 'omarTheChatbot.html', context=context)

    # Restarting the conversation after a session is done
    elif state == "4":
        context = {"state": "0", "chat_history": temp_arr}
        return render(request, 'omarTheChatbot.html', context=context)


def homePage(request):
    return render(request, "welcomePage.html")


def registerPage(request):
    return render(request, "register.html")


def guestPage(request):
    return render(request, "omarTheChatbot.html")
